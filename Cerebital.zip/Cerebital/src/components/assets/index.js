export * from './cerebital_logo.jpg';
export * from './ketan_wachkar.jpg'