export const DropArea = ({ selectedFile }) => {
  const handleDrop = (e) => {
    e.preventDefault();
    if (selectedFile) {
      const droppedFile = selectedFile;
      console.log("Dropped file:", droppedFile, e);
    }
  };

  return (
    <div
      className="dropzone"
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
    >
      <div>Drop Here</div>
      {selectedFile?.type === "png" && (
        <img src={selectedFile?.url} alt="png"></img>
      )}
      {/* {selectedFile?.type === "pdf" && <img src={selectedFile?.url} alt="png"></img>} */}
      {selectedFile && selectedFile.type === "application/pdf" && (
        <embed
          src={selectedFile.url}
          type="application/pdf"
          width="90%"
          height="100%"
        />
      )}
    </div>
  );
};
