import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
// import "./Header.css"

export const SelectDropDown = ({ handleSelectFile }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const dispatch = useDispatch();
  const { files } = useSelector((state) => state.counter);
  const [isActive, setIsActive] = useState(false);
  const [selected, setIsSelected] = useState("Choose one");

  const handleFileSelect = (file) => {
    handleSelectFile(file);
    dispatch(selectedFile(file));
  };

  return (
    <div>
      <div className="App">
        <div className="dropdown">
          <div
            onClick={(e) => {
              setIsActive(!isActive);
            }}
            className="dropdown-btn"
          >
            {selected}
            <span
              className={isActive ? "fas fa-caret-up" : "fas fa-caret-down"}
            />
          </div>
          <div
            className="dropdown-content"
            style={{ display: isActive ? "block" : "none" }}
          >
            <div
              className="item"
              onClick={(e) => {
                setIsSelected(e.target.textContent);
                setIsActive(!isActive);
              }}
            >
              {files.map((file, index) => (
                <div
                  key={index}
                  className="dropdown-item"
                  draggable
                  onDragEnd={() => setSelectedFile(file)}
                  onClick={() => handleFileSelect(file)}
                >
                  {file.name}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
