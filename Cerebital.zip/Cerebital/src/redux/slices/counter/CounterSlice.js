import { createSlice } from "@reduxjs/toolkit";

export const CounterSlice = createSlice({
  initialState : {
    // count: 0,
    files : [{
      name:"one",type:"png",url:"https://img.hotimg.com/Screenshot-2023-12-20-135553.png"
    },{
      name:"Two",type:"application/pdf",url:"https://pdf.ac/3CV3Wf"
    }],
    selectedFile:{}
  },
  name : "counter",
  reducers : {
    setSelected: (state,{payload}) => {
     state.selectedFile=payload
    },
  },
})


export const {setSelected} = CounterSlice.actions
export default CounterSlice.reducer