import React, { useState } from "react";
import {
  Box,
  Menu,
  MenuItem,
  SwipeableDrawer,
  Typography,
} from "@mui/material";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import InputBase from "@mui/material/InputBase";
import Avatar from "@mui/material/Avatar";
import Badge from "@mui/material/Badge";
import cerebital_logo from "../../components/assets/cerebital_logo.jpg";
import SearchIcon from "@mui/icons-material/Search";
import ketan_wachkar from "../../components/assets/ketan_wachkar.jpg";
import HelpOutline from "@mui/icons-material/HelpOutline";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import AddBoxRoundedIcon from "@mui/icons-material/AddBoxRounded";
import ArrowForwardIosRoundedIcon from "@mui/icons-material/ArrowForwardIosRounded";
import HomeRoundedIcon from "@mui/icons-material/HomeRounded";
import { useDispatch, useSelector } from "react-redux";
import { setSelected } from "../../redux/slices/counter/CounterSlice";
import { redirect } from "react-router-dom";
import { SelectDropDown } from "../../components";
// import "./Header.css"

export const HeaderSideBar = ({ handleSelectFile }) => {
  const [sideBar, setSideBar] = useState(null);

  function handleClick(event) {
    setSideBar(event.currentTarget);
  }

  function handleClose() {
    setSideBar(null);
  }

  return (
    <Box position="static">
      <Toolbar style={{ background: "white", justifyContent: "space-between" }}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <Typography
            variant="body1"
            component="div"
            align="center"
            sx={{ flexGrow: "0.1", mr: "10px" }}
          >
            <img
              style={{ height: "80px", display: "flex" }}
              src={cerebital_logo}
              alt="Logo"
            />
          </Typography>
          <Typography
            variant="h6"
            component="div"
            sx={{ color: "grey", mr: "10px" }}
          >
            Workspace Test
          </Typography>

          <Typography variant="h6" component="div" sx={{ color: "grey" }}>
            Dashboard 1
          </Typography>
        </Box>
        <Box>
          <div style={{ display: "flex", alignItems: "center" }}>
            {/* <IconButton size="large" sx={{ mr: 1 }}>
              <SearchIcon />
            </IconButton>
            <InputBase
              placeholder="Search..."
              inputProps={{ "aria-label": "search" }}
            /> */}
            <SelectDropDown handleSelectFile={handleSelectFile} />
          </div>
        </Box>
        <Box
          sx={{
            display: "flex",
            direction: "row",
            justifyContent: "space-evenly",
          }}
        >
          <IconButton size="large">
            <AddBoxRoundedIcon />
          </IconButton>
          <IconButton size="large">
            <HelpOutline />
          </IconButton>
          <IconButton size="large">
            <LightModeOutlinedIcon />
          </IconButton>
          <IconButton size="large">
            <NotificationsNoneOutlinedIcon />
            <Badge badgeContent={2} color="secondary"></Badge>
          </IconButton>
          <Avatar alt="Profile" src={ketan_wachkar} sx={{ ml: 2 }} />
        </Box>
      </Toolbar>

      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          mt: "200px",
        }}
      >
        <IconButton
          size="large"
          onClick={handleClick}
          onMouseEnter={handleClick}
        >
          <ArrowForwardIosRoundedIcon />
        </IconButton>
        <SwipeableDrawer
          //   id="simple-menu"
          anchorEl={sideBar}
          open={Boolean(sideBar)}
          onClose={handleClose}
          onMouseLeave={handleClose}
        >
          <MenuItem
            onClick={() => {
              redirect("/home");
            }}
          >
            <HomeRoundedIcon />
          </MenuItem>
        </SwipeableDrawer>
      </Box>
    </Box>
  );
};
