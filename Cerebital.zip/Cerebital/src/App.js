import "./App.css";
// import { Update } from "./components/Update";
import { Route, Routes, BrowserRouter, Router } from "react-router-dom";
import { HeaderSideBar } from "./container/header/HeaderSideBar";
import { DropArea } from "./components";
import { useState } from "react";
// import { SelectDropDown } from "./components/header/SelectDropDown";
// import { SearchItem } from "./redux/slices/searchItems/SearchItem";

function App() {
  const [selectFile, setSelectFile] = useState();

  const handleSelectFile = (fileSelected) => {
    setSelectFile(fileSelected);
  };
  return (
    <div className="App">
      {/* <h1><Update/></h1> */}
      <HeaderSideBar onHandleSelect={handleSelectFile} />
      <BrowserRouter>
        <Routes>
          <Route path="/home" element={<HeaderSideBar />} />
        </Routes>
        <DropArea selectedFile={selectFile} />
      </BrowserRouter>
      {/* <SelectDropDown/> */}
      {/* <Header />   */}
      {/* <SearchItem /> */}
    </div>
  );
}

export default App;
